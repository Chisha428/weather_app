# Weather App

## Overview

A Django application providing real-time weather updates.

## Installation

1. Unzip file.
2. Install requirements: `pip install -r requirements.txt`.
3. Run migrations: `python manage.py migrate`.
4. Start server: `python manage.py runserver`.

## Usage

1. Add the api Key(7eb060d2ba2098b40809def4c36d2309) to the index.js file in "weather_project/weather_app/static/js/index.js" line 1.
2. Open browser at `http://localhost:8000`.
3. Enter city name to get weather updates.

## Features

*   Real-time weather updates
*   City search functionality
*   Temperature, humidity and description display

## License

MIT License.

## Contact

Chisha Onesimus
chishaonesimus@gmail.com

