module.exports = {
  content: [
    "./templates/**/*.html",
    "./weather_app/templates/**/*.html",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}