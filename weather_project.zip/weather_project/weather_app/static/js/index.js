const api_key = ''
const cityInput = document.querySelector('.city_input');
const weatherForm = document.querySelector('.weather_form');
const card = document.querySelector('.card');
const cityDisplay = document.querySelector('.city_display');
const tempDisplay = document.querySelector('.temp_display');
const humidityDisplay = document.querySelector('.humidity_display');
const descriptionDisplay = document.querySelector('.description_display');
const errorDisplay = document.querySelector('.error_display');
const icon = document.querySelector('.description-icon');

weatherForm.addEventListener('submit', (e) => {
  e.preventDefault(); // Prevent default form submission

  const city = cityInput.value.trim();

  if (city) {
    get_weather_data(city, api_key);
    card.classList.remove('hidden'); // Show card
    errorDisplay.textContent = ''; // Clear error message
  } else {
    card.classList.remove('hidden'); // Show card
    errorDisplay.textContent = 'Please enter a city'; // Display error message
    cityDisplay.textContent = '';
    tempDisplay.textContent = '';
    humidityDisplay.textContent = '';
    descriptionDisplay.textContent = '';
    icon.textContent = '';
  }
});

async function get_weather_data(city, api_key) {
  const apiURL = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${api_key}&units=metric`;
  try {
    const response = await fetch(apiURL);
    const data = await response.json();
    console.log(data);
    console.log(data.cod);

    // Update UI with weather data
    if(data.cod == 200){
        cityDisplay.textContent = data.name;
        tempDisplay.textContent = `Temperature: ${data.main.temp}°C`;
        humidityDisplay.textContent = `Humidity: ${data.main.humidity}%`;
        descriptionDisplay.textContent = data.weather[0].description
        icon.textContent = getWeatherIcon(data.weather[0].main)
        icon.classList.remove('hidden');
    }
    else if(data.cod == 404){
        card.classList.remove('hidden'); // Show card
        errorDisplay.textContent = 'City not found'; // Display error message
        cityDisplay.textContent = '';
        tempDisplay.textContent = '';
        humidityDisplay.textContent = '';
        descriptionDisplay.textContent = '';
        icon.textContent = '';

    }
    else{
        card.classList.remove('hidden'); // Show card
        errorDisplay.textContent = 'Something went wrong, try again later'; // Display error message
        cityDisplay.textContent = '';
        tempDisplay.textContent = '';
        humidityDisplay.textContent = '';
        descriptionDisplay.textContent = '';
        icon.textContent = '';

    }

  } catch (error) {
    console.error(`Error fetching weather data: ${error}`);
  }
}

// Helper function to get weather icon
function getWeatherIcon(weatherCondition) {
  switch (weatherCondition) {
    case 'Clear':
      return 'sunny';
    case 'Clouds':
      return 'cloud';
    case 'Rain':
      return 'cloud';
    case 'Snow':
      return 'snowy';
    default:
      return 'cloud';
  }
}